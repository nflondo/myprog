2 + 5;
4 - 3;
5 - 9;
3 * 5;
36 / 6;
36 / 5;

20 % 2;
19 % 2;

// twenty an even number?
20 % 2 === 0; // true

var counter = 0;
counter = counter + 1;
counter;

counter += 1;
counter++;

counter += 5;
counter += -4;

counter -= 1;
counter--;
counter;

counter *= 2;

"cat" + "dog";
"cat " + "dog";
"cat" + " and " + "dog";

// More info:
// https://developer.mozilla.org/en-US/docs/JavaScript/Guide/Expressions_and_Operators#Arithmetic_operators
// https://developer.mozilla.org/en-US/docs/JavaScript/Guide/Expressions_and_Operators#String_operators
