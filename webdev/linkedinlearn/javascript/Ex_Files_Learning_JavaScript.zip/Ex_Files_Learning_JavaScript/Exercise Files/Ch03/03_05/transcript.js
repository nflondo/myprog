var myArray = [];
myArray;

var daysOfTheWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday'];
daysOfTheWeek;

var myArray = [
0, 1, 2,
'string1', 'string2', 'string3',
true, false
];
myArray;

var counties = [
	'Belknap',
	'Strafford',
	'Carroll',
	'Rockingham'
];
counties;

var arrayOfStuff = [
	{'name' : 'value'},
	[1, 2, 3],
	true,
	'nifty'
];
arrayOfStuff;
arrayOfStuff.length;

// More info:
// https://developer.mozilla.org/en-US/docs/JavaScript/Guide/Values%2C_variables%2C_and_literals#Array_literals
// https://developer.mozilla.org/en-US/docs/JavaScript/Reference/Global_Objects/Array