12;
("strings");
true;

{
}
var emptyObject = {};
emptyObject;

var notEmptyObject = {
  label: "value",
  label2: "value2"
};
notEmptyObject;

// More info:
// https://developer.mozilla.org/en-US/docs/JavaScript/Guide/Working_with_Objects
// https://developer.mozilla.org/en-US/docs/JavaScript/Reference/Global_Objects/Objects
