var year=2012,month='October',day=31,holiday='Halloween';

var year   = 2012,       month    =    'October', day =          31,          holiday='Halloween';

var year = 2012,
	month = 'October',
	day = 31,
	holiday = 'Halloween';
	
var year    = 2012,
	month   = 'October',
	day     = 31,
	holiday = 'Halloween';

var tinyAlmanac={'year':2012,'month':'October','day':31,'holiday':'Halloween'};

var tinyAlmanac = {
	'year' : 2012,
	'month' : 'October',
	'day' : 31,
	'holiday' : 'Halloween'
};

var longString = "Four score \
and seven years ago \
our fathers brought forth \
on this continent \
a new nation";

// More info: 
// These are not specifications on whitespace, but the Mozilla recommended coding style concerning whitespace.
// https://developer.mozilla.org/en-US/docs/Mozilla/Developer_guide/Coding_Style#Whitespace