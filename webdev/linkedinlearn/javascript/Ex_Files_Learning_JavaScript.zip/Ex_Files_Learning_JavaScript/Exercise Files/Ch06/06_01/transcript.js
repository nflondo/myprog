console.log('Arf');
console.log('Woof');
console.log('Meow');
console.log('Moooooooooooo');

function speak() {
	console.log('Arf');
	console.log('Woof');
	console.log('Meow');
	console.log('Moooooooooooo');
}

speak();

// More info:
// https://developer.mozilla.org/en-US/docs/JavaScript/Guide/Functions
// https://developer.mozilla.org/en-US/docs/JavaScript/Reference/Statements/function